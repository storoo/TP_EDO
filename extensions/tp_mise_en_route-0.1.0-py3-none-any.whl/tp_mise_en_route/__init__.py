"""Extension JupyterLab / JupyterLite « mise en route automatique » des TP (voir ../README.md)."""


def _jupyter_labextension_paths():
    return [{"src": "labextension", "dest": "tp-mise-en-route"}]
